Prerequisite to run:
1)	Python 3
2)	Required Packages: robotframework, requests, robotframework-requests, jsonpath_rw, jsonpath_rw_ext, robotframework-jsonlibrary
3)	Required Library: RequestsLibrary, Collections, SeleniumLibrary, OperatingSystem, String, json
4)	Firefox has to be installed
5)	Geckodriver-v0.30.0-win64 for FireFox has to be installed and PATH has to be configured (or geckodriver.exe can be put into python directory for example C:\Users\Favian\AppData\Local\Programs\Python\Python310)

Steps to run:
1)	Open cmd.exe and run the OppenheimerProjectDev.jar with command: java -jar OppenheimerProjectDev.jar
2)	Unzip the package pythonProjectFavian
3)	Open cmd.exe
4)	Navigate into folder pythonProject (root folder to run commands)
5)	Execute command:	robot TestCases\.
	for example: C:\Users\Favian\PycharmProjects\pythonProject>robot TestCases\.
6)	All test cases should be running and results should be displayed
7)	Refer to log.html and report.html in same directory for more details on outcome

Issues encountered:
1)	Response code 202 and code 500 are undocumented so I assumed 202 is a successful response and 500 is a syntax error.
2)	User Story 1 AC 1: Natid are not unique and hence duplicated records are allowed.
3)	User Story 1 AC 1: After inserting a record with natid of 3 or less characters, the server will crash.
4)	User Story 4 AC 4: After calculation of tax relief amount, the normal rounding rule is not consistant for some values. For example, $0.367 becomes $0.00, $3.67 becomes $3.67, $0.734 becomes $0.74, $5.505 becomes $5.00

Regarding the questions:
1)	In my experience, functional requirements are end users' specific demands as basic facilities the system should offer. They are usually easier to define than non-functional requirements as the end result can be seen directly. A given input will be processed by an operation to produce an expected output.
2)	Non-functional requirements are usually not explicitly specified by the end users but rather by the technical people. They are qaulity constraints on how the system should fulfill the functional requirements. They are usually not mandatory and more difficult to define. For example if the user only requests a button on the web page, the button is the functional requirement. It is up to the technical team to define the non-functional requirements like color, size, shape and text on the button. But if the user requests a red-colored button, then the color here will become a functional requirement.
3)	My test suite covers all the functional requirements based on the acceptance criteria defined by the 5 user stories. There are some documentation and tags for each test case. Additionally, I added somes non-functional test cases like sending 100 insert records within 1 second to see if the server can handle such a load. For the benefit of running all the testcases successfully in this project, I refrained from adding Negative test cases to my test suite.

- Favian Choo Yong Cheng
